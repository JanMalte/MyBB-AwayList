 
<?php

/**
 * @version     show_list.php 2012-01-06
 * @package     MyBB.Plugins
 * @subpackage  AwayList
 * @author      Malte Gerth <http://www.malte-gerth.de>
 * @copyright   Copyright (C) Malte Gerth. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

$l['followingErrors'] = 'Folgende Fehler sind aufgetreten:';
$l['errorNotActive'] = 'Das Plugin wurde nicht aktiviert. Bitte aktiviere das Plugin um diese Seite anzuzeigen.';

$l['back'] = 'Zurück ';

$l['liste'] = 'Aufenthaltsliste';