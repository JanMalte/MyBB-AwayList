 
<?php

/**
 * @version     show_list.php 2012-01-06
 * @package     MyBB.Plugins
 * @subpackage  AwayList
 * @author      Malte Gerth <http://www.malte-gerth.de>
 * @copyright   Copyright (C) Malte Gerth. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

$l['followingErrors'] = 'The following errors occurred:';
$l['errorNotActive'] = 'The plugin is not activated. You will be redirected to the index in 10 seconds.';

$l['back'] = 'Go back ';